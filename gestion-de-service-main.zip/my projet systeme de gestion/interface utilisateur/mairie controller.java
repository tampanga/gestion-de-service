
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/mairie")
public class MairieController {
@Autowired
private MairieService mairieService;
// Gestion des services
@GetMapping("/services")
public List<Service> getAllServices() {
return mairieService.getAllServices();
}
@PostMapping("/services")
public Service createService(@RequestBody Service service) {
return mairieService.createService(service);
}
// Gestion des demandes
@GetMapping("/demandes")
public List<Demande> getAllDemandes() {
return mairieService.getAllDemandes();
}
@PostMapping("/demandes")
public Demande createDemande(@RequestBody Demande demande) {
return mairieService.createDemande(demande);
}
@PutMapping("/demandes/{id}")
public Demande updateDemandeStatus(@PathVariable Long id, @RequestParam String
status) {
return mairieService.updateDemandeStatus(id, status);
